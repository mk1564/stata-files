The CEPII GeoDist database is licensed under the [Etalab Open Licence 2.0](doc/open-licence.pdf).

The World Development Indicators is licensed under [ Creative Commons Attribution 4.0 International License (CC BY 4.0)](https://datacatalog.worldbank.org/public-licenses#cc-by).

![Creative Commons License](https://i.creativecommons.org/l/by/4.0/88x31.png)

All derived work is licensed under a [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/).