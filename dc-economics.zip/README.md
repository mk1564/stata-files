# dc-economics-data
Data for the Economics curriculum of Data Carpentry.

## References
- CEPII, 2011. "GeoDist Database." Downloaded from http://www.cepii.fr/distance/dist_cepii.dta on 2019-06-05.
- Mayer, T. & Zignago, S. 2011. "Notes on CEPII’s distances measures: the GeoDist Database." CEPII Working Paper 2011-25. http://www.cepii.fr/CEPII/en/publications/wp/abstract.asp?NoDoc=3877
- World Bank, 2019. "World Development Indicators 2018." Downloaded from https://datacatalog.worldbank.org/dataset/world-development-indicators on 2019-06-05.